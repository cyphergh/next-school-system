export async function createNote(userId:number, text:string,) {
 try {
    
 } catch (error:any) {
    throw Error(error.toString());
 }
}