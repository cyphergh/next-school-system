import React from "react";
import UI from "./ui";

async function Page() {
  return <UI></UI>;
}

export default Page;
