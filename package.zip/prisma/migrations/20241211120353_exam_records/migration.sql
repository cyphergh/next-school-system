-- AlterTable
ALTER TABLE "ExamRecords" ALTER COLUMN "classScore" DROP NOT NULL,
ALTER COLUMN "examScore" DROP NOT NULL;
