-- AlterTable
ALTER TABLE "Examination" ADD COLUMN     "release" BOOLEAN NOT NULL DEFAULT false;
